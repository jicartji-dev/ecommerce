
function changeImage(imageUrl) {
    document.getElementById('mainProductImage').src = imageUrl;
}

